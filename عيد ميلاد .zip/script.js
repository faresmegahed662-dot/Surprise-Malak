/* =========================
   بداية الصفحة
========================= */

function startPage() {

    document.getElementById("mainContent").scrollIntoView({
        behavior: "smooth"
    });

    const music = document.getElementById("music");

    music.play().catch(() => {
        console.log("المتصفح منع تشغيل الموسيقى تلقائيًا.");
    });

}


/* =========================
   عداد عيد الميلاد
========================= */

// غيّر السنة لو محتاج
const birthday = new Date("August 26, 2026 00:00:00").getTime();


function updateCountdown() {

    const now = new Date().getTime();

    const difference = birthday - now;


    if (difference <= 0) {

        document.getElementById("days").textContent = "00";
        document.getElementById("hours").textContent = "00";
        document.getElementById("minutes").textContent = "00";
        document.getElementById("seconds").textContent = "00";

        return;
    }


    const days = Math.floor(
        difference / (1000 * 60 * 60 * 24)
    );

    const hours = Math.floor(
        (difference / (1000 * 60 * 60)) % 24
    );

    const minutes = Math.floor(
        (difference / (1000 * 60)) % 60
    );

    const seconds = Math.floor(
        (difference / 1000) % 60
    );


    document.getElementById("days").textContent =
        String(days).padStart(2, "0");

    document.getElementById("hours").textContent =
        String(hours).padStart(2, "0");

    document.getElementById("minutes").textContent =
        String(minutes).padStart(2, "0");

    document.getElementById("seconds").textContent =
        String(seconds).padStart(2, "0");
}


setInterval(updateCountdown, 1000);

updateCountdown();


/* =========================
   مفاجأة زر الهدية
========================= */

function showSurprise() {

    const surprise = document.getElementById("surprise");

    surprise.classList.add("show");

    surprise.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

    createHearts(25);
}


/* =========================
   القلوب المتحركة
========================= */

function createHeart() {

    const heart = document.createElement("div");

    heart.className = "heart";

    heart.textContent = "❤️";

    heart.style.left =
        Math.random() * 100 + "vw";

    heart.style.fontSize =
        Math.random() * 20 + 15 + "px";

    heart.style.animationDuration =
        Math.random() * 3 + 4 + "s";


    document.body.appendChild(heart);


    setTimeout(() => {

        heart.remove();

    }, 7000);

}


setInterval(createHeart, 700);


/* =========================
   قلوب إضافية وقت المفاجأة
========================= */

function createHearts(number) {

    for (let i = 0; i < number; i++) {

        setTimeout(() => {

            createHeart();

        }, i * 100);

    }

}